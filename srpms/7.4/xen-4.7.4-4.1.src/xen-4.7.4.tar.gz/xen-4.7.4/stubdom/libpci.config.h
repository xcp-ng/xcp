#define PCI_OS_MINIOS
#define PCI_HAVE_STDINT_H
#define PCI_PATH_IDS_DIR "."
#define PCI_COMPRESSED_IDS
#define PCI_IDS "pci.ids.gz"
